/* SC ORI DANZXX HOSTING
NOTE!! 
SCRIPT KILUA VERSION NEW 1.0
OWNER SCRIPT : DANZXX HOSTING*/
require("./all/module.js")

//========== Setting Owner ==========//
global.owner = "6283149813374" // kalo ga paham chat gw dstu 🗿
global.namaowner = "Kilua Owner"
global.ownername = "Danzxx Hosting"
global.versi = "1.0"

//======== Setting Bot & Link ========//
global.namabot = "Kilua New Script" 
global.idsaluran = "120363319787389012@newsletter"
global.ppvid = "https://files.catbox.moe/mvqovl.mp4"
global.linkyt = 'https://www.youtube.com/@danzxxhost'
global.author = "`Danzxx Hosting`"

//========== Setting Panel ==========//
global.domain = '' //ISI DOMAIN PANEL
global.apikey = '' //ISI APIKEY PLTA MU KALO G TAU LIAT YT
global.capikey = '' //ISI APIKEY PLTC MU KALO G TAU LIAT YT
global.eggsnya = '15' //PAKE ID EGGS MU KALO GA TAU DEFAULT AJA
global.location = '1' //JANGAN DIGANTI KALO G MAU EROR

//========== Setting Event ==========//
global.welcome = true
global.autoread = false
global.anticall = false
global.owneroff = false

//========= Setting Message =========//
global.msg = {
"error": "Error Bang Kilua",
"done": "Done Bang Kilua", 
"wait": "Sabar Dong Kilua Sedang Memproses Tunggu Sebentar . . .", 
"group": "*• Group Only* Fitur Ini Hanya Untuk Di Dalam Grup!", 
"private": "*• Private Chat* Fitur Ini Hanya Untuk Didalam Private Chat!", 
"admin": "*• Kilua Only* Fitur Ini Hanya Untuk Admin Grup!", 
"adminbot": "*• Bot Kilua Admin* Fitur Ini Dapat Digunakan Ketika Bot Kilua Menjadi Admin", 
"owner": "Fitur Khusus Owner Bot Kilua", 
"developer": "*• Developer Only* Fitur Ini Hanya Untuk Developer Kilua"
}


let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update ${__filename}`))
	delete require.cache[file]
	require(file)
})